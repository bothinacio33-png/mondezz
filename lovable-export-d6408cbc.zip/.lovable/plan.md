## Objetivo

Reconstruir `src/pages/Produto.tsx` para replicar fielmente o layout da Atelier Clássico (imagem de referência), e ajustar o estilo do badge de desconto em `ProductCard` para itálico/fino padrão "99% off". Remover totalmente a seção de avaliações.

## 1. Ajuste do badge de desconto (ProductCard)

Hoje: pílula dourada sólida `bg-brass`, semibold, "-99%".
Novo: texto itálico fino, sem fundo, no padrão "**99%** off" (número em destaque, "off" minúsculo).

```tsx
<span className="font-serif italic font-light text-[13px] text-[#C8A24B]">
  <span className="font-medium not-italic">{discountPct}%</span> off
</span>
```

Manter empilhado top-left abaixo do "Frete grátis".

## 2. Reconstrução da página de produto

Layout em **duas colunas** (esquerda = galeria + miniaturas; direita = buy box), seguindo a referência. Cor de fundo geral **branco puro**. Bordas finíssimas em cinza-bege `#E8E4DC`. Sem sobreposições — todo conteúdo flui em fluxo normal, com `min-w-0` nas colunas grid e `flex-wrap` em linhas de meta-info para suportar textos maiores.

### 2.1 Header de categoria/breadcrumb
Faixa fina superior com breadcrumb existente (mantém).

### 2.2 HERO — grid `lg:grid-cols-[1.4fr_1fr]`, gap 32px

**Coluna esquerda (galeria):**
- Imagem mestre grande, fundo branco (sem aspect ratio fixo de card; usar `aspect-[4/3]` como referência).
- Setas laterais **circulares brancas com sombra leve** (substituir as atuais barras escuras) — `bg-white/90 shadow-md rounded-full h-10 w-10 text-ink`.
- Selo circular "ATELIER CLÁSSICO" (logo monograma) sobreposto top-left pequeno.
- **Linha de miniaturas horizontais** abaixo (4–5 thumbs visíveis, scroll horizontal).
- Badge de desconto removido da galeria (já vai no buy box).

**Coluna direita (buy box):**
Estrutura na ordem da referência:
1. Pílula "Aproveite 5% OFF no PIX" — pequena verde-clara no topo.
2. **Título** serif Playfair, peso normal, 1.6rem.
3. **Estrelas** com média + "(N avaliações)" — link âncora removido.
4. **Linha de preços** compacta:
   - "De R$ X,XX" risco fino cinza
   - "R$ Y,YY" grande, cor `#C8A24B` (brass) — não preto
   - "ou 10x de R$ Z sem juros" texto fino
5. Faixa cinza-bege clara `#F5F1EA` com **"COMPRE EM 1 CLIQUE"** — botão preto sólido full-width.
6. Card pílula bege `#FBF8F2` com ícone caminhão: "**APROVEITE A OFERTA ESPECIAL AGORA**" + linha texto pequena.
7. Bloco "**Acabamento**" — label uppercase + swatches circulares (componente atual `WoodFinishSelector`).
8. Bloco "Quantidade" inline com — / + e input.
9. **CTA WhatsApp verde** `#1F4E3D` full-width — manter.
10. Calculadora de CEP inline (manter).
11. Trio de selos pequenos (compra segura / entrega / madeira) — manter.

Largura do buy box flexível com `min-w-0` para nada estourar; preço usa `flex-wrap items-baseline gap-x-3`.

### 2.3 Seção "Detalhes do Produto"
Bloco creme `#FBF8F2` largura total da grid central (max-w 1180), padding 32px.
- Subtítulo serif: "Escrivaninha Sage com Gaveta — Design Multifuncional em Eucalipto Maciço…"
- **4 quadrados horizontais** (grid 4 colunas em desktop, 2 em tablet, 1 mobile) com fundo branco e borda fina, cada um com:
  - micro-label uppercase brass (Organização, Multifuncionalidade, etc.)
  - título curto
  - descrição pequena
- Frase em itálico serif abaixo, em card cinza-bege com borda esquerda brass.

### 2.4 Acordeão de seções
Manter `ProductAccordion`, mas **estilo plano com fundo branco** e seções iniciando todas FECHADAS (defaultOpen `null`). Seções:
- Sobre
- **Materiais & Construção** — 4 cards bege (mantém)
- **Especificações** — tabela zebrada bege/branca (mantém)
- **Perguntas frequentes** (placeholder simples)
- Vídeo (se houver)

Cada seção com chevron `+ / −` à direita, divisores `#EAE6DD`.

### 2.5 Tabela de especificações (fora do acordeão também?)
Conforme imagem, há uma tabela completa abaixo do acordeão — manter como está (tabela zebrada).

### 2.6 REMOVER seção de avaliações
Apagar o bloco `#avaliacoes` inteiro e o link âncora nas estrelas. Não importar mais `ProductReviews`.

### 2.7 "Catálogo Acabamentos" + Relacionados
Manter `RelatedProducts` (já existente) com 5 cards horizontais — encaixa na referência.

### 2.8 Rodapé
Mantém `SiteFooter`.

## 3. Princípios de robustez (anti-overflow)

- Toda `grid` recebe `min-w-0` nas filhas de texto.
- Linhas de preço/meta usam `flex-wrap`.
- Imagens com `max-w-full h-auto`.
- Buy box sem `whitespace-nowrap` em textos longos.
- Botões CTA com `text-balance` e padding vertical, sem altura fixa.
- Containers com `max-w-[1180px]` mas conteúdo interno fluido.

## 4. Arquivos afetados

- `src/components/product/ProductCard.tsx` — badge de desconto reformulado.
- `src/pages/Produto.tsx` — reescrita do JSX (lógica de fetch, estados, e cálculos preservados).
- `src/components/product/ProductGalleryHero.tsx` — trocar setas escuras por circulares brancas.

Nenhum arquivo novo necessário. Sem mudanças em schema Sanity ou queries.

## Fora do escopo

- Não mexer em Header/Footer/Home.
- Não alterar integração Sanity nem WhatsApp.
- Avaliações ficam fora (apenas escondidas/removidas da página).
